<div class="notice notice-error is-dismissible">
  <div class="acfbsContent acfbsContent--notice">
    <h4>
      <?= __('ACF: Better Search error!', 'acf-better-search'); ?>
    </h4>
    <p>
      <?= __('Unfortunately, but this plugin requires the Advanced Custom Field plugin version 5 for all functionalities to work properly. Please install the latest version of the ACF plugin.', 'acf-better-search'); ?>
    </p>
  </div>
</div>