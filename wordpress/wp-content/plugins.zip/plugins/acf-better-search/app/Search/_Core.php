<?php

  namespace AcfBetterSearch\Search;

  class _Core
  {
    public function __construct()
    {
      new Init();
    }
  }