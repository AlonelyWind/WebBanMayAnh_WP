﻿=== Christmas Greetings ===
Contributors: Technocrackers
Donate link: http://www.technocrackers.com/
Tags: christmas,christmas-greetings,christmas holiday,santa-claus,Snowflakes,christmas snow,holiday snow
Requires at least: 3.0.1
Tested up to: 5.5.1
Requires PHP: 5.2.4
Stable tag: 1.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Ho..Ho..Ho..!! Let Users Groove InTo Holiday Merriment & Experience The Joy Of Christmas With Winter Wonderland Plug-ins to add Holiday Cheer!

It's the christmastide round the corner and time to spread sparkling festive spirit of the holidays with Christmas carols and candies, Jingle bells, Santa's sleigh and let the Joy of Happiness be the reason for the season. The holiday tradition embraces Christmas Eve as the time of the year to give and to receive.

On the same note, why to left behind your much appreciated and valued website users? Hence, indulge them in multi-special business plugins to immerse and amaze them at the perfect nick of Yuletide time. The plugins showcase's greetings and messages to your visitors and provides you with overwhelming customizable options to let your users feel warm and cozy by the Christmas tree on a wintery night. It provides promotions to store products, coupons with woo-commerce so as to let your visitors start unwrapping the ecards, gifts, presents and messages. Moreover, you can easily personalize it.

= Basic Features =

01.	Easy to install, as no need to be occupied with shortcodes.
02.	User-friendly dashboard.
03.	Automatic set-up based on scheduled time and date.
04.	Real time preview option from the Admin panel.
05.	Multiple options lets you either Enable / Disable Snowflakes, Floating Santa effect, Gift Box animation and    many more
06.	Customize or edit greeting message from the backend.
07. Option to apply effects on All page or Only Home page.



= WOO-COMMERCE/PREMIUM FEATURES: =
 [Buy Premium](https://technocrackers.com/christmas-greetings/)  

01.	Christmas and New Year theme.
02.	New Year theme with Fireworks effects.
03.	Coupon code promotion with custom greeting message.
04.	Multiple options for both themes for 'Feature Product Listing' with greeting message.
05. Option to apply effects on All page or specific pages.


= Let the Magic of Christmas Begin...!!! Ho..Ho..Ho..Merry Christmas! =



= COMPATIBILITY: = 

Divi-Theme Compatible, X-theme Compatible, Woo-commerce Compatible.

= Support =

For any queries feel free to drop a line at <a href="mailto:wordpress@technocrackers.com">wordpress@technocrackers.com</a>. 


== Installation ==

= Automatic Installation =

* Go to your plugin browser inside your wordpress installation and search `Christmas Greetings` by keyword. Then choose "Christmas Greetings" and click install. It will be installed shortly.
* Activate the plugin from `Plugins` menu after installation

= Manual Installation =

* Download the latest version and extract the folder to the `/wp-content/plugins/` directory
* The plugin will appear as inactive in your `Plugins` menu
* Activate the plugin through the `Plugins` menu in WordPress





== Screenshots ==

1. Snow Type And Preview.
2. Santa Type and Preview.
3. Christmas-Greetings Dashboard.
4. Christmas-Greetings Advance-settings.
5. Christmas-Greetings Realtime Preview.


== Changelog ==

= 1.2.4 =
* Compatibility check.
* Security patches.

= 1.2.2.3 =
* Css optimization.
* JS optimization.
* Image optimization. 

= 1.2.2.2 =
* Solved- JS conflict issue.

= 1.2.2.1 =
* Paid version bug solved.

= 1.2.2 =
* Paid version bug solved.

= 1.2.1 =
* Added features to free and paid version.
* Improvements and bugs solved.

= 1.2.0 =
* bug fixes.
* tested latest version compatibility.

= 1.1.9 =
* bug fixes related to advance setting tab.

= 1.1.8 =
* Responsive version fixes.

= 1.1.7 =
* Stable Realese.
* Tested upto wordpress 5.0.
* fixed image issues.

= 1.1.6 =
* Stable Realese.
* Tested latest version compatibility.
* fixed bugs.

= 1.1.5 =
* Tested latest version compatibility.
* Domain deactivate option.
* Gift box disable option.

= 1.1.4 =
* Tested latest version compatibility.
* Fixed preview issue.
* optimized images.

= 1.1.3 =
* Solved Header image overlaping issue.
* Solved Mountain Issue.
* Implemented music option.

= 1.1.2 =
* Stable Realese.
* Implemented Snow Effect.
* Implemented Santa Animation.
* New Santa Animation.
* Music Added.
* Graphics Added.


= 1.1 =
* Stable Realese.
* Added New-Year Theme and Animation.
* Woo-commerce Product pramotion added.
* Coupon code support added.
* Tested on Wordpress 4.9.1.

= 1.0 =
* Finalised stable Realese.



== Upgrade Notice ==

= 1.1.2 =
New Santa Animation.
Music Added.
Graphics Added.

= 1.1 =
Added advanced features.
Tested on wordpress 4.9.1.

= 1.0 =
Finalised Stable Release.
