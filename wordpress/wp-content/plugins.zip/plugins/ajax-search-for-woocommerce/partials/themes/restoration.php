<?php

// Exit if accessed directly
if ( ! defined( 'DGWT_WCAS_FILE' ) ) {
	exit;
}

echo do_shortcode('[wcas-search-form layout="classic"]');
