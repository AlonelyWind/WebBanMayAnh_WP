( function( $ ) {

	$( document ).ready( function( $ ) {

		$( '#clean-commerce-settings-metabox-container' ).tabs();

	});

} )( jQuery );
